#include<iostream>
using namespace std;


int fib(int n){
	if(n == 0 || n == 1){
		return n;
	}
	return fib(n - 1) + fib(n - 2);
}


// Memoization
int fibM(int n, int* storage){

	if(storage[n] != -1){
		return storage[n];
	}
	if(n == 0 || n == 1){
		storage[n] = n;
	}else{
		storage[n] = fibM(n - 1, storage) + fibM(n - 2, storage);
	}
	return storage[n];
}

int fibM(int n){
	int* storage = new int[n + 1];
	for(int i = 0; i <= n; i++){
		storage[i] = -1;
	}

	int ans = fibM(n, storage);
	delete [] storage;
	return ans;
}
// DP 
int fibDP(int n){

	if(n == 0){
		return 0;
	}

	int* storage = new int[n + 1];
	//fill  Base Case Cells
	storage[0] = 0; // 0th fib number is 0
	storage[1] = 1;
	
	for(int i = 2; i <= n; i++){
		// storage[i] -> storage[i] is storing ith fib number
		storage[i] = storage[i - 1] + storage[i - 2];
	}

	int ans = storage[n];
	delete [] storage;
	return ans;
}

int staircase(int n){
	if(n == 0 || n == 1){
		return 1;
	}
	if(n == 2){
		return 2;
	}
	return staircase(n - 1) + staircase(n - 2) + staircase(n - 3);
}

int staircaseM(int n, int* storage){
	
	if(storage[n] != -1){
		return storage[n];
	}
	if(n == 0 || n == 1){
		storage[n] = 1;
	}
	else if(n == 2){
		storage[n] = 2;
	}else{
		storage[n] = staircaseM(n - 1, storage) + staircaseM(n - 2, storage) + staircaseM(n - 2, storage);
	}
	return storage[n];
}

int staircaseM(int n){
	int* storage = new int[n + 1];
	for(int i = 0; i <= n; i++){
		storage[i] = -1;
	}

	int ans = staircaseM(n, storage);
	delete [] storage;
	return ans;{

}

int minStepsToOne(int n){

	if(n == 1){
		return 0;
	}
	int op1, op2 = INT_MAX, op3 = INT_MAX;
	op1 = minStepsToOne(n - 1);
	if(n % 2 == 0){
		op2 = minStepsToOne(n / 2);
	}
	if(n % 3 == 0){
		op3 = minStepsToOne(n / 3);
	}

	return min(op1, min(op2, op3)) + 1;
}

int main(){
	
	int n = 4;
	cout << fibM(n) << endl;
	cout << fib(n) << endl;


}

