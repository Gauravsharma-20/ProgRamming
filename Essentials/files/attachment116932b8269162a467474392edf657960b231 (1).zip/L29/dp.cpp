#include<iostream>
#include<cmath>
using namespace std;


int fib(int n){
	if(n == 0 || n == 1){
		return n;
	}
	return fib(n - 1) + fib(n - 2);
}


// Memoization
int fibM(int n, int* storage){

	if(storage[n] != -1){
		return storage[n];
	}
	if(n == 0 || n == 1){
		storage[n] = n;
	}else{
		storage[n] = fibM(n - 1, storage) + fibM(n - 2, storage);
	}
	return storage[n];
}

int fibM(int n){
	int* storage = new int[n + 1];
	for(int i = 0; i <= n; i++){
		storage[i] = -1;
	}

	int ans = fibM(n, storage);
	delete [] storage;
	return ans;
}
// DP 
int fibDP(int n){

	if(n == 0){
		return 0;
	}

	int* storage = new int[n + 1];
	//fill  Base Case Cells
	storage[0] = 0; // 0th fib number is 0
	storage[1] = 1;
	
	for(int i = 2; i <= n; i++){
		// storage[i] -> storage[i] is storing ith fib number
		storage[i] = storage[i - 1] + storage[i - 2];
	}

	int ans = storage[n];
	delete [] storage;
	return ans;
}

int staircase(int n){
	if(n == 0 || n == 1){
		return 1;
	}
	if(n == 2){
		return 2;
	}
	return staircase(n - 1) + staircase(n - 2) + staircase(n - 3);
}

int staircaseM(int n, int* storage){
	
	if(storage[n] != -1){
		return storage[n];
	}
	if(n == 0 || n == 1){
		storage[n] = 1;
	}
	else if(n == 2){
		storage[n] = 2;
	}else{
		storage[n] = staircaseM(n - 1, storage) + staircaseM(n - 2, storage) + staircaseM(n - 2, storage);
	}
	return storage[n];
}

int staircaseM(int n){
	int* storage = new int[n + 1];
	for(int i = 0; i <= n; i++){
		storage[i] = -1;
	}

	int ans = staircaseM(n, storage);
	delete [] storage;
	return ans;

}

int minStepsToOne(int n){

	if(n == 1){
		return 0;
	}
	int op1, op2 = INT_MAX, op3 = INT_MAX;
	op1 = minStepsToOne(n - 1);
	if(n % 2 == 0){
		op2 = minStepsToOne(n / 2);
	}
	if(n % 3 == 0){
		op3 = minStepsToOne(n / 3);
	}
	return min(op1, min(op2, op3)) + 1;
}

int minStepsToOneDP(int n){

	if(n == 0){
		return 0;
	}

	int* storage = new int[n + 1];
	storage[0] = 0;
	// min steps to bring 1 to 1
	storage[1] = 0;
	
	for(int i = 2; i <= n; i++){
		// storage[i] -> will store min steps required to bring i to 1
		int op1, op2 = INT_MAX, op3 = INT_MAX;
		op1 = storage[i - 1];
		if(i % 2 == 0){
			op2 = storage[i / 2];
		}
		if(i % 3 == 0){
			op3 = storage[i / 3];
		}
		storage[i] = min(op1, min(op2, op3)) + 1;
	}
	int ans = storage[n];
	delete [] storage;
	return ans;
}

int mod = pow(10,9) + 7;

int balancedBTs(int h){
	if(h == 0 || h == 1){
		return 1;
	}
	long x = balancedBTs(h - 1);
	long y = balancedBTs(h - 2);
	
	long part1 = (x * x) % mod;
	long part2 = (((2 * x) % mod) * y) % mod;
	//return (x * x + 2* x * y) % mod ;
	return (part1 + part2) % mod;
}

int balancedBTsDP(int h){

	int* storage = new int[h];
	storage[0] = 1;
	storage[1] = 1;
	
	for(int i = 2; i <= h; i++){
		// storage[i] -> count of balance BTs of Height i
		long x = storage[i - 1];
		long y = storage[i - 2];
		long part1 = (x * x) % mod;
		long part2 = (((2 * x) % mod) * y) % mod;
		storage[i] =  (part1 + part2) % mod;	
	}
	int ans = storage[h];
	delete [] storage;
	return ans;
}

int lcs(string s1, string s2){
	if(s1.length() == 0 || s2.length() == 0){
		return 0;
	}

	if(s1[0] == s2[0]){
		return 1 + lcs(s1.substr(1), s2.substr(1));
	}else{
		// Don't include first char of s1
		int op1 = lcs(s1.substr(1), s2);
		int op2 = lcs(s1, s2.substr(1));
		//int op3 = lcs(s1.substr(1), s2.substr(1));
		return max(op1, op2);  
			//max(op1, max(op2, op3));
	}
}

int lcsM(string s1, string s2, int** storage){
	int m = s1.length();
	int n = s2.length();
	if(storage[m][n] != -1){
		return storage[m][n];
	}
	if(m == 0 || n == 0){
		storage[m][n] = 0;
		return storage[m][n];
	}else if(s1[0] == s2[0]){
		storage[m][n] = lcsM(s1.substr(1), s2.substr(1), storage) + 1;
	}else{
		int op1 = lcsM(s1.substr(1), s2, storage);
		int op2 = lcsM(s1, s2.substr(1), storage);
		storage[m][n] = max(op1, op2);
	}
	return storage[m][n];
}

int lcsM(string s1, string s2){
	
	int m = s1.length();
	int n = s2.length();

	//int storage[m + 1][n + 1];
	int** storage = new int*[m + 1];
	for(int i = 0; i <= m; i++){
		storage[i] = new int[n + 1];
		for(int j = 0; j <= n; j++){
			storage[i][j] = -1;
		}
	}

	int ans = lcsM(s1, s2, storage);
	// Delete
	return ans;
}

int lcsDP(string s1, string s2){

	int m = s1.length();
	int n = s2.length();

	//int storage[m + 1][n + 1];
	int** storage = new int*[m + 1];
	for(int i = 0; i <= m; i++){
		storage[i] = new int[n + 1];
	}

	// Base Case Cells
	// Set First row to 0s
	for(int j = 0; j <= n; j++){
		storage[0][j] = 0;
	}
	// Set First column to 0s
	for(int i = 0; i <= m; i++){
		storage[i][0] = 0;
	}

	for(int i = 1; i <= m; i++){
		for(int j = 1; j <= n; j++){
			// Fill storage[i][j]
			if(s1[m - i] == s2[n - j]){
				storage[i][j] = 1 + storage[i - 1][j - 1];
			}else{
				storage[i][j] = max(storage[i][j - 1], storage[i - 1][j]);
			}
		}
	}
	
	int ans = storage[m][n];
	// Delete storage
	retuen ans;
}

int main(){	
	//int n = 4;
	string s1 = "aeij";
	string s2 = "iabej";
	cout << lcsM(s1, s2) << endl;
	cout << lcs(s1, s2) << endl;
	/*
	int h;
	cin >> h;
	cout << balancedBTs(h) << endl;
	*/
	//cout << minStepsToOneDP(10) << endl; 	
	//cout << minStepsToOne(10) << endl; 
	//cout << fibM(n) << endl;
	//cout << fib(n) << endl;

}

