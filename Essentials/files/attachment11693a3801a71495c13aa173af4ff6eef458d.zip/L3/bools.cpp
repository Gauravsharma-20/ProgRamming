#include<iostream>
using namespace std;

int main(){

	bool a = false;
	bool b = 100;

	if(b){
		cout << "If " << endl;
	}else{
		cout << "Else " << endl;
	}

	cout << a << " " << b << endl;

}

