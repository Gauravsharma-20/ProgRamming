#include<iostream>
#include<climits>
using namespace std;

int main(){

	// 2^31 - 1
	int a = INT_MAX;
	int b = INT_MIN; // -2^31

}

