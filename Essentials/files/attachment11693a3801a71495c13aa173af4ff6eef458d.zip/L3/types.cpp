#include<iostream>
#include<cmath>
using namespace std;

int main(){


	//int a = 5.7;

	//int a = (double)(5 / 7);
//	double a = 5.0 / 7;

	int a = round(5.7);

	double root = sqrt(4);

	cout << a << endl;
	//cout << sizeof(short) << endl;


}

