#include<iostream>
using namespace std;

int main(){

	int a = 10;

	/*
	if(a > 0){
		cout << "Positive" << endl;
	}
	if(a < 0){
		cout << "Negative" << endl;
	}
	if(a == 0){
		cout << "Zero " << endl;
	}*/


	/*if(a > 0){
		cout << "Positive" << endl;
	}else if(a < 0){
		cout << "Negative" << endl;
	}else{
		cout << "Zero " << endl;
	}*/


}

