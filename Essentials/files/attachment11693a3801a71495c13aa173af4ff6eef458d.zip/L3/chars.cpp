#include<iostream>
using namespace std;

int main(){

	char ch;
	
	cin >> ch;
	if(ch >= 'a' && ch <= 'z'){
		cout << "Lower Case " << endl;
	}
	/*
	int i = 1;

	if(i > ch){
		cout << "If" << endl;
	}else{
		cout << "else" << endl;
	}*/


	//ch = 'A';
	//ch = '1';
//	cout << ch << " " << i << endl;


}

