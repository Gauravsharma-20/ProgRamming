#include<iostream>
using namespace std;

int main(){


	//int i = 1;
	int n = 5;
/*
	for(int i = 1; i <= n; i++){
		if(i == 3){
			continue;
		}
		cout << i << endl;
	}
*/

	int i = 1;
	/* 
	for( ; i <= n; i++){

	}*/
	/*for( ; ;){

		i++;
	}*/

	/*
	for(int i = 1, j = 10; i < 5 && j < 50; i++, j *= 10){

	}*/


	/*while(i <= n){
		if(i == 3){
			i++;
			continue;
		}
		i++;
		cout << i << endl;
	}*/


}

