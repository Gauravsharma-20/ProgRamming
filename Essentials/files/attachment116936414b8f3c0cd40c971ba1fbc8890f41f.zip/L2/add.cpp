#include<iostream>
using namespace std;

int main(){

/*
	int a = 10;
	int b = 20;
	int c = a + b;
*/
// Single Line Comment ->	double a = 10.7;
	
	int a, b;
	//int b;
	cin >> a >> b;
	//cin >> b;
	int c;
	c = a + b;
	cout << c << endl;

}

