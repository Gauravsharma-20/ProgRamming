#include<iostream>
#include<string>
using namespace std;

int main(){

	//string arr[4];

	// Empty String
	string s = "";

	string arr[] = {"that", "is","are", "am"};

	//cout << arr << endl;
	cout << arr[2] << endl;
	cout << arr[2][1] << endl;
	cout << arr[2].length() << endl;
	/*
	string str = "that";
	str += " is are ";

	cout << str << endl;

	//cout << str[1] << endl;

	cout << str.substr(1,2) << endl;
	cout << str.substr(1) << endl;
*/
	/*cout << str.length() << endl;
	cout << str.size() << endl;
*/


}

