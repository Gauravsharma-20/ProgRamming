#include<iostream>
using namespace std;

int main(){


	int n;
	cin >> n;
	int prev, curr;
	cin >> prev;
	bool isDec = true;
	bool isValid = true;
	int count = 1;
	while(count < n){
		cin >> curr;
		if(){	
			// curr is less than prev

		}else if(){
			// curr is greater than prev

		}else{
			// curr and prev are equal
			isValid = false;
			break;
		}

		prev = curr;
		count++;
	}



}

