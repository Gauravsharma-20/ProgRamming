#include<iostream>
#include<cstring>
using namespace std;

int main(){


	char str1[] = "abc";
	char str2[] = "adc";

	int arr1[] = {1,2};
	int arr2[] = {1,2};


	cout << strcmp(str1, str2) << endl;

	/*if(str1 == str2){
		cout << "If " << endl;
	}else{
		cout << "Else " << endl;
	}*/


}

