#include<iostream>
using namespace std;
#include "Fraction.h"


int main(){


//	Fraction f1;
	Fraction f1(2,5);
	Fraction f2(3,4);

	//cout << f1.num << endl;

	f1.add(f2);

	f1.print();

	//demo();	

}


void demo(){

}

