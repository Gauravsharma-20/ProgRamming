#include<iostream>
using namespace std;
#include "Pair.h"


int main(){

	Pair<int, double> p;


	/*
	Pair<int> p(10,11);
	
	Pair<double> p2(3.4, 6.8);;
	p.print();
	p2.print();
	
	Pair<char>* p3 = new Pair<char>('a','y');
	p3->print();	
	*/
	/*
	Pair<string> p3;
	Pair<Student> p4;
	*/
}

