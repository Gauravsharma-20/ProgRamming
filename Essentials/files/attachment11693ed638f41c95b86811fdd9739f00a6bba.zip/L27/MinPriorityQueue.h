#include<vector>

class MinPriorityQueue{

	 vector<int> heap; 
		
	public:

	 MinPriorityQueue(){

	 }
		
	 int size(){
		 return heap.size();
	 }

	 bool empty(){
		 return heap.empty();
	 }

		int min(){
			if(heap.size() == 0){
				return 0;
			}
			return heap[0];
		}
		
		void insert(int elem){
				heap.push_back(elem);
				//Up Heapify
				int childIndex = heap.size() - 1;
				int parentIndex = (childIndex - 1) / 2;

				while(childIndex > 0){


					if( heap[parentIndex] > heap[childIndex]){ 
						// (compare(heap[parentIndex], heap[childIndex])
						// heap[parentIndex] < heap[childIndex]
						// swap
						int temp = heap[childIndex];
						heap[childIndex] = heap[parentIndex];
						heap[parentIndex] = temp;
						childIndex = parentIndex;
						parentIndex = (childIndex - 1) / 2;
					}else{
						break;
					}
				}
		}
		
		int removeMin(){
			if(heap.empty()){
				return 0;
			}
			int valueRemoved = heap[0];
			heap[0] = heap[heap.size() - 1];
			heap.pop_back();

			// Heapify - Downward
			int parentIndex = 0;
			int leftChildIndex = 2 * parentIndex + 1;
			int rightchildIndex = 2* parentIndex + 2;
	
			while(leftChildIndex < heap.size()){
				
				int minIndex = parentIndex;
				if(heap[leftChildIndex] < heap[minIndex]){
					minIndex = leftChildIndex;
				}
				if(rightchildIndex < heap.size() && heap[rightchildIndex] < heap[minIndex]){
					minIndex = rightchildIndex;
				}
				if(minIndex != parentIndex){
						// Swap minIndex and parentIndex
						int temp = heap[parentIndex];
						heap[parentIndex] = heap[minIndex];
						heap[minIndex] = temp;
						parentIndex = minIndex;
						leftChildIndex = 2 * parentIndex + 1;
						rightchildIndex = 2* parentIndex + 2;
				}else{
					break;
				}
			}

	
			return valueRemoved;
		}


};
