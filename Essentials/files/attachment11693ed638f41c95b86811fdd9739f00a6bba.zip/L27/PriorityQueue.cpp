#include<iostream>
#include<queue>
#include<vector>
using namespace std;
#include "MinPriorityQueue.h"


void insertInVirtualHeap(int heap[], int i){
	// Up heapify
	// Element inserted is ith element
	int childIndex = i;
	int parentIndex = (childIndex - 1) / 2;
	
	// Upward Heapify
   while(childIndex > 0){
				if(heap[childIndex] < heap[parentIndex]){
													// swap
							int temp = heap[childIndex];
							heap[childIndex] = heap[parentIndex];
							heap[parentIndex] = temp;
							childIndex = parentIndex;
							parentIndex = (childIndex - 1) / 2;
				}else{
					break;
				}
	}
} 

void deleteFromVirtualHeap(int arr[], int size){

	int temp = arr[0];
	int arr[0] = arr[size - 1];
	arr[size - 1] = temp;
	size--;
	// Down Heapify
		
}

int heapsort(int arr[], int size){

	for(int i = 1; i < size; i++){
		insertInVirtualHeap(arr, i);
	}

	// all the elements in the array are arranged in the form of heap now

	for(int i = 0; i < size - 1; i++){
		deleteFromVirtualHeap(arr, size - i);
	}

}


vector<int> kLargest(int input[], int n, int k){
	
	priority_queue<int, vector<int>, greater<int> > pq;
	int i = 0;

	for(; i < k; i++){
		pq.push(input[i]);
	}

	for(; i < n; i++){
		if(input[i] > pq.top()){
			pq.pop();
			pq.push(input[i]);
		}
	}
	vector<int> ans;
	while(!pq.empty()){
		ans.push_back(pq.top());
		pq.pop();
	}
	return ans;
}

int main(){

	//	MinPriorityQueue pq;
	int arr[] = {6,1,8,2,9};

	// Max
	//	priority_queue<int> pq;

	// Min PQ
	priority_queue<int, vector<int>, greater<int> > pq;

	for(int i = 0; i < 5; i++){
		pq.push(arr[i]);
	}

	while(! pq.empty()){
		cout << pq.top() << endl;
		pq.pop();
	}
	/*
		 for(int i = 0; i < 5; i++){
		 pq.insert(arr[i]);
		 }

		 while(!pq.empty()){
		 cout << pq.removeMin() << endl;
		 }*/


}

