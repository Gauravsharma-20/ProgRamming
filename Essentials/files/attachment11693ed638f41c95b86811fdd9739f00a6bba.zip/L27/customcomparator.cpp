#include<iostream>
#include<string>
#include<queue>
using namespace std;

class Compare{

	public:
		bool operator() (string s1, string s2){
			return s1.length() < s2.length();
		}
};


class ComparePairs{
	public:
	bool operator() (pair<int,int> p1, pair<int, int> p2){
		return p1.first > p2.first;
	}
};


int main(){


	string arr[] = {"abhh", "a", "hj", "cbeg", "deghi"};
	//priority_queue<string, vector<string>, greater<string> > pq;
	priority_queue<string, vector<string>, Compare> pq;

	for(int i = 0; i < 5; i++){
		pq.push(arr[i]);
	}

	while(! pq.empty()){
		cout << pq.top() << endl;
		pq.pop();
	}

}

