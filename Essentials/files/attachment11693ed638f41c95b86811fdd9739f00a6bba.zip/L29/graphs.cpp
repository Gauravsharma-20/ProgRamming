#include<iostream>
using namespace std;

int main(){

	int v, e;

	cin >> v >> e;
	int** adjMatrix = new int*[v];	

	for(int i = 0; i < v; i++){
		adjMatrix[i] = new int[v]();
	}

	for(int i = 0; i < e; i++){
		int v1, v2;
		cin >> v1 >> v2;
		adjMatrix[v1][v2] = 1;
		adjMatrix[v2][v1] = 1;
	}

}

