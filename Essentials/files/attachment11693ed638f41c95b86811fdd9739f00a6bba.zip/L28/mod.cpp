#include<iostream>
#include<cmath>
using namespace std;

int main(){

	int mod = pow(10,9) + 7;
	int num = INT_MAX;	
	
	int ans = (num + 1l) % mod;

	cout << num << endl;
	cout << ans << endl;

	/*cout << num << endl;
	num++;
	cout << num << endl;
	*/
}

