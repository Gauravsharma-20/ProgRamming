#include<iostream>
using namespace std;
#include "BinaryTreeNode.h"


class BST{
	BinaryTreeNode<int>* root;
	
	public:
	BST(){
		root = NULL;
	}

	void print(){
		//
		print(root);
	}

	void print(BinaryTreeNode<int>* root){

	}

	bool search(int elem){
		
		return search(root, elem);

		/*if(root == NULL){
			return false;
		}
		if(root->data == elem){
			return true;
		}else if(root->data > elem){
			return search(elem);
		}else{
			return search(elem);
		}*/
	}

	bool search(BinaryTreeNode<int>* root, int elem){
		if(root == NULL){
			return false;
		}
		if(root->data == elem){
			return true;
		}else if(root->data > elem){
			return search(root->left, elem);
		}else{
			return search(root->right, elem);
		}
	}

	void insert(int elem){
			root = insert(root, elem);	
	}

	BinaryTreeNode<int>* insert(BinaryTreeNode<int>* root, int elem){	
		if(root == NULL){
			root = new BinaryTreeNode<int>(elem);
			return root;
		}
		if(root->data > elem){
			rot->left = insert(root->left, elem);
		}else{
			root->right = insert(root->right, elem);
		}
		return root;
	}

	void deleteData(int elem){
			root = deleteData(root, elem);
	}

	BinaryTreeNode<int>* deleteData(BinaryTreeNode<int>* root, int elem){
			if(root == NULL){
				return root;
			}
			if(root->data == elem){
				// 0 children
				if(root->left == NULL && root->right == NULL){
					delete root;
					return NULL;
				}else if(root->right == NULL){
						// 1 child - only left child
						BinaryTreeNode<int>* newRoot = root->left;
						delete root;
						return newRoot;
				}else if(root->left == NULL){
						// 1 child - only right child
						BinaryTreeNode<int>* newRoot = root->right;
						delete root;
						return newRoot;
				}else{
					// 2 child
						//	find inorder successor
						BinaryTreeNode<int>* successor = root->right;
						while(successor->left != NULL){
							successor = successor->left;
						}
						// Replace root->data with successor data
						root->data = successor->data;
						// Delete Successor
						root->right = deleteData(root->right, successor->data);
						return root
			}else if(root-> data > elem){
					root->left = deleteData(root->left, elem);
			}else{
					root->right = deleteData(root->right, elem);
			}
			return root;
	}

};



int main(){


	/*
	BinaryTreeNode<int>* root = takeInput();
	search(root, data);
	*/

	BST tree;
	cout << 	tree.search(10) << endl;;
	tree.insert(20);
	tree.print();

}


