#include<iostream>
#include<queue>
using namespace std;
#include "TreeNode.h"

TreeNode<int>* createTree(){

	TreeNode<int>* node1 = new TreeNode<int>(10);
	TreeNode<int>* node2 = new TreeNode<int>(20);
	TreeNode<int>* node3 = new TreeNode<int>(30);
	TreeNode<int>* node4 = new TreeNode<int>(40);
	TreeNode<int>* node5 = new TreeNode<int>(50);

	node1->children.push_back(node2);
	node1->children.push_back(node3);
	node1->children.push_back(node4);
	node4->children.push_back(node5);	

	return node1;
}

int countNode(TreeNode<int>* root){

	// Only if root is passed NULL from Main
	if(root == NULL){
		return 0;
	}

	/*
	if(root->children.size() == 0){
		return 1;
	}*/

	int finalCount = 0;
	for(int i = 0; i < root->children.size(); i++){
			// Calling recursion on ith child
		 int countOfNodesInIthChild = countNode(root->children[i]);
		finalCount += countOfNodesInIthChild;
	}
	return finalCount + 1;
}


int sumOfNodes(TreeNode<int>* root) {

	int sum = 0;
	for(int i = 0; i < root->children.size(); i++){
		int ithSubTreesum = sumOfNodes(root->children[i]);
		sum += ithSubTreesum;
	}
	return sum + root->data;

}

TreeNode<int>* maxDataNode(TreeNode<int>* root) {
	
	// Assuming root is maximum
	TreeNode<int>* maxNode = root;

	for(int i = 0; i < root->children.size(); i++){
		TreeNode<int>* maxNodeInChildSubTree = maxDataNode(root->children[i]);
		if(maxNodeInChildSubTree->data > maxNode->data){
			maxNode = maxNodeInChildSubTree;
		}
	}
	return maxNode;
}

void printLevelWise(TreeNode<int>* root) {

	queue<TreeNode<int>*> pendingNodes;
	pendingNodes.push(root);

	while(!pendingNodes.empty()){
		TreeNode<int>* currentNode = pendingNodes.front();
		pendingNodes.pop();
		cout << currentNode->data << ":";
		int childCount = currentNode->children.size();
		int i = 0;
		for(; i < childCount - 1; i++){
			cout << currentNode->children[i]->data<<",";
			pendingNodes.push(currentNode->children[i]);
		}
		if(childCount != 0){
			cout << currentNode->children[i]->data;
			pendingNodes.push(currentNode->children[i]);
		}
		cout << endl;
	}
}

void preOrder(TreeNode<int>* root){
	cout << root->data << " ";
	for(int i = 0; i < root->children.size(); i++){	
		preOrder(root->children[i]);
	}
}


int main(){

	vector<int> v;
	unsigned int i = v.size() - 1;
	cout << i << endl;
	/*TreeNode<int>* root = createTree();
	for(int i = 0; i < root->children.size(); i++){
		cout << root->children[i]->data << " ";
	}
	cout << endl;
	*/
	/*
	TreeNode<int> node1(10);
	TreeNode<int> node2(20);
	TreeNode<int> node3(30);
	TreeNode<int> node4(40);

	node1.children.push_back(&node2);
	node1.children.push_back(&node3);
	node1.children.push_back(&node4);

	cout << node1.children.size() << endl;
	
	cout << node1.children[0]->data << endl;

	for(int i = 0; i < node1.children.size(); i++){
		cout << node1.children[i]->data << endl;
	}
	*/
}

