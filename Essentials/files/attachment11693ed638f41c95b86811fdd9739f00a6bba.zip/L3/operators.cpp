#include<iostream>
using namespace std;

int main(){

	int a = 10;
	int b = 20;

	if(++a > 10 || ++b > 20){
		cout << "If " << endl;
	}else{
		cout << "Else " << endl;
	}

	cout << "a " << a << " b " << b << endl;
	
	
	
	
	
	/*//a = a + 1;
	// a += 1;
	a++; // Post Increment
	//++a;  // Pre Increment
	
	int b = a++;
	
	cout << a << " " << b << endl;
	
	// a = a + 2;
	// a += 2; // a -= 2 // a *= 2 // a /= 2
//	bool a = true;
//	cout << !a << endl;
*/

}

