#include<iostream>
using namespace std;

int findPivotIndex(int arr[], int s, int e){
	// Choose Pivot
	int pivot = arr[s]; // Randomised pivot 
	int pivotIndex = start;
	for(int i = s + 1; i <= e; i++){
		if(arr[i] < pivot){
				pivotIndex++;
		}
	}
	// Place pivot at its correct position
		arr[s] = arr[pivotIndex];
		arr[pivotIndex] = pivot;
	// Everything to left of pivot is smaller than pivot
	// Everything to right of pivot is greater than pivot
	int i = s, j = e;
	while(i < pivotIndex && j > pivotIndex){
		if(arr[i] < pivot){
			i++;
		}else if(arr[j] >= pivot){
			j--;
		}else{
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			i++;
			j--;
		}
	}
	return pivotIndex;
}

void quickSort(int arr[], int s, int e){

	if(s >= e){
		return;
	}
	// Partition
	int pivotIndex = findPivotIndex(arr, s, e);
	// Recursive calls
	// Left Part
	quickSort(arr, s, pivotIndex - 1);
	quickSort(arr, pivotIndex + 1, e);
}

int main(){


}

