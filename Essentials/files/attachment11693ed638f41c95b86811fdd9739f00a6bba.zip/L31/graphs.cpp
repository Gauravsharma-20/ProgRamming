#include<iostream>
#include<vector>
#include<queue>
using namespace std;

void dftraversal(int** adjMatrix, int v, int currentVertex, bool* visited){
	cout << currentVertex << " ";
	for(int vertex = 0; vertex < v; vertex++){
		if(adjMatrix[currentVertex][vertex] == 1 && !visited[vertex]){
			// Unvisited Neighbors
			visited[vertex] = true;
			dftraversal(adjMatrix, v, vertex, visited);
		}
	}
}

void dftraversal(int** adjMatrix, int v){
	bool* visited = new bool[v]();
	for(int i = 0; i < v; i++){
		if(!visited[i]){
			visited[i] = true;
			dftraversal(adjMatrix, v, i, visited);
		}
	}
}

bool hasPath(int** adjMatrix, int v, int v1, int v2, bool* visited){
	if(v1 == v2){
		return true;
	}
	// Explore paths from all unvisited neighbors of v1
	for(int vertex = 0; vertex < v; vertex++){
		if(adjMatrix[v1][vertex] == 1 && !visited[vertex]){
			// Check path from neighbor(vertex) to v2
			visited[vertex] = true;
			bool pathFromNeigh = hasPath(adjMatrix, v, vertex, v2, visited);
			if(pathFromNeigh){
				return true;
			}
			/*else{
				// Move to next vertex
			}*/
		}
	}
	return false;
}	

bool hasPath(int** adjMatrix, int v, int v1, int v2){

	bool* visited = new bool[v]();
	visited[v1] = true;
	return hasPath(adjMatrix, v, v1, v2);
}

vector<int> getPath(int** adjMatrix, int v, int v1, int v2, bool* visited){

	if(v1 == v2){
		vector<int> path;
		path.push_back(v1);
		return path;
	}
	// Explore paths from all unvisited neighbors of v1
	for(int vertex = 0; vertex < v; vertex++){
		if(adjMatrix[v1][vertex] == 1 && !visited[vertex]){
			// Check path from neighbor(vertex) to v2
			visited[vertex] = true;
			vector<int> pathFromNeigh = getPath(adjMatrix, v, vertex, v2, visited);
			if(pathFromNeigh.size() > 0){
				pathFromNeigh.push_back(v1);
				return pathFromNeigh;
			}
			/*else{
				// Move to next vertex
			}*/
		}
	}
	vector<int> path;
	return path;

}	
vector<int> getPath(int** adjMatrix, int v, int v1, int v2){
	bool* visited = new bool[v]();
	visited[v1] = true;
	return getPath(adjMatrix, v, v1, v2);
}

void bftraversal(int** adjMatrix, int v,int v1,int v2){

	bool* visited = new bool[v]();
	queue<int> pendingVertices;
	pendingVertices.push(0);
	visited[v1] = true;
	//visited[0] = true;

	int* parent = new int[v]; 
	parent[v1] = -1;

	while(! pendingVertices.empty()){
			int currentVertex = pendingVertices.front();
			pendingVertices.pop();
			if(currentVertex == v2){
				// Node found

			}
			cout << currentVertex <<  " ";
			for(int vertex = 0; vertex < v; vertex++){
				if(adjMatrix[currentVertex][vertex] == 1 && !visited[vertex]){
					visited[vertex] = true;	
					pendingVertices.push(vertex);
					parent[vertex] = currentVertex;
				}
		}
	}
}

int main(){
	int v, e;
	cin >> v >> e;
	int** adjMatrix = new int*[v];	
	for(int i = 0; i < v; i++){
		adjMatrix[i] = new int[v]();
	}
	for(int i = 0; i < e; i++){
		// For every Edge
		int v1, v2;
		cin >> v1 >> v2;
		adjMatrix[v1][v2] = 1;
		adjMatrix[v2][v1] = 1;
	}
	
	/*// Find path from v1 to v2 
	int v1, v2;
	cin >> v2 >> v2;
	vector<int> path = getPath(adjMatrix, v, v1, v2);
	// Print vector
	*/
	dftraversal(adjMatrix, v);

}

