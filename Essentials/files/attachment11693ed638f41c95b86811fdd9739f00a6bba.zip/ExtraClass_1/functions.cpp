#include<iostream>
using namespace std;


void C(int a){
	int b = 10;
	a++;
	cout << "Inside C " << " a " << a << endl;
}

void B(int a){
	int b = 10;
	b =100;
	a++;
	C(a);
	cout << "Inside B " << " a " << a << endl;
}


void A(int a){
	int b = 10;
	a++;
	B(a);
	cout << "Inside A " << " a " << a << endl;
}


int main(){
	int b = 10;
	int a = 10;
	A(a);
	cout << "Inside Main " << " a " <<  a << endl;
}

