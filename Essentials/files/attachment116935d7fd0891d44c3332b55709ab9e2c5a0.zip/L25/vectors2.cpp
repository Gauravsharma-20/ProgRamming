#include<iostream>
#include<vector>
using namespace std;

int main(){

	vector<int> v;

	vector<int>* vptr = new vector<int>();
	vptr->push_back(10);
	vptr->at(0) = 100;
	(*vptr)[0] = 200;

	/*
	cout << "Size " << v.size() <<  " " << v.capacity() << endl;
	for(int i = 1; i <= 9; i++){
		v.push_back(i);
		cout << "Round " << i << " " ;
		cout << "Size " << v.size() <<  " Capacity " << v.capacity() << endl;

	}
	cout << "Pop Elements " << endl;
for(int i = 1; i <= 9; i++){
		v.pop_back();
		cout << "Round " << i << " " ;
		cout << "Size " << v.size() <<  " Capacity " << v.capacity() << endl;

	}*/
	/*
	v.push_back(10); // insertion at the end
	v.push_back(20);
	v.push_back(30);
	v.push_back(40);
	
	//cout << v[1] << endl;
	//v[6] = 100;
	//v.at(6) = 100; Error - out of range

	//v.pop_back();
	for(int i = 0; i < v.size(); i++){
		cout << v[i] << " " << v.at(i) << endl;
	}*/
}

