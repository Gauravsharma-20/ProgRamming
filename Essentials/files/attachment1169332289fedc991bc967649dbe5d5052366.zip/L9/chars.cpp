#include<iostream>
using namespace std;

int main(){


	int i = 10;
	double j = 1.5;

	int *p = &i;
	double* d = &j;

	//char arr[] = "abc";
	//char *ptr = "abc";



}

