#include<iostream>
#include<queue>
using namespace std;

template<class T>
class demo{

};


int main(){

	queue<int> q;
	q.push(1);
	q.front();
	q.push(10);
	q.pop();
	q.empty();
	q.size();
}

