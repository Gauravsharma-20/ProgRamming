#include<iostream>
using namespace std;

void printSubstrings(char str[]){

	int n = strlen(str);
	for(int start = 0; start < n; start++){		
		for(int end = start; end < n ; end++){
				// Loop to print chars from start to end	
		}
			
	}

}


int main(){



}

