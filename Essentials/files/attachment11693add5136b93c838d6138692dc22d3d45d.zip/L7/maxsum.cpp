#include<iostream>
using namespace std;


long maxPathSum(int ar1[], int ar2[], int m, int n){

	long sum1 = 0, sum2 = 0, finalSum = 0;

	int i = 0, j = 0;

	while(i < m && j < n){
			if(ar1[i] < ar2[j]){

			}else if(ar1[i] > ar2[j]){

			}else{
				// Equal
			}
	}



	return finalSum;
}



int main(){



}

