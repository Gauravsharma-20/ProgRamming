#include<iostream>
using namespace std;
#include "MinPriorityQueue.h"

void insertInVirtualHeap(){
	// Up heapify
	int childIndex = i;
}

void deleteFromVirtualHeap(int arr[], int size){
	
	int temp = arr[0];
	int arr[0] = arr[size - 1];
	arr[size - 1] = temp;
	size--;
	// Down Heapify

}

int heapsort(int arr[], int size){

	for(int i = 1; i < size; i++){
		insertInVirtualHeap(arr, i);
	}
	for(int i = 0; i < size - 1; i++){
		deleteFromVirtualHeap(arr, size - i);
	}

}


int main(){

	MinPriorityQueue pq;
	int arr[] = {6,1,8,2,9};
	
	for(int i = 0; i < 5; i++){
		pq.insert(arr[i]);
	}

	while(!pq.empty()){
		cout << pq.removeMin() << endl;
	}


}

