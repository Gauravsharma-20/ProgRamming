#include<iostream>
#include<unordered_map>
#include<string>
using namespace std;


char highestOccuringChar(string str){
	unordered_map<char, int> charFreqMap;
	int maxFreq = 0;
	char maxFreqChar;
	for(int i = 0; i < str.length(); i++){
		/*if(charFreqMap.count(str[i]) == 0){
				// char doesn't exists in map
				charFreqMap[str[i]] = 1;	
		}else{
				//int oldFreq = charFreqMap[str[i]];
				//charFreqMap[str[i]] = oldFreq + 1;	
				
				//charFreqMap[str[i]] = charFreqMap[str[i]] + 1;
				charFreqMap[str[i]]++;
		}*/
			charFreqMap[str[i]]++;
	}		
	for(int i = 0; i < str.length(); i++){
		int currentCharFreq = charFreqMap[str[i]];
		if(currentCharFreq > maxFreq){
				maxFreq = currentCharFreq;
				maxChar = str[i];
		}
	}
	return maxChar;
}

vector<int> removeDuplicates(vector<int> input){	
	vector<int> ans;
	unordered_map<int, bool> numberMap;
	for(int i = 0; i < input.size(); i++){
		if(numberMap.count(input[i]) == 0){
			ans.push_back(input[i]);
			numberMap[input[i]] = true;
		}
	}
	return ans;
}


int main(){

	unordered_map<string, int> map;

	// Insert In Map
	map["this"] = 0; // "this" is the key and 0 in value
	map["at"] = 20;
	cout << map.size() << endl;

	map["this"] = 100;

	// search 
	int v = map["the"];

	//cout << map["at"] << endl;
	cout << map.at("this") << endl;

	// Delete key value pair from map -> map.erase("this");

	cout << map.size() << endl;

	//cout << map["those"] << endl;
	//cout << map.at("those") << endl;

	//cout << map.count("those") << endl;

	//cout << map.size() << endl;

}

