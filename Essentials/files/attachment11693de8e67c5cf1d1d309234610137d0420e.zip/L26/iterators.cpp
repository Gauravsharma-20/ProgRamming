#include<iostream>
#include<vector>
#include<unordered_map>
using namespace std;

int main(){

	unordered_map<string, int> hmap;
	hmap["that"] = 22;
	hmap["at"] = 10;
	hmap["am"] = 16;
	hmap["these"] = 22;

	unordered_map<string, int>::iterator it = hmap.begin();
	while(it != hmap.end()){
		cout << "Key " << it->first << " Value " << it->second << endl;
		it++;
	}

	/*
	vector<int> v;
	for(int i = 1; i <= 5; i++){
		v.push_back(i);
	}
	vector<int>::iterator it = v.begin();
	//v.insert(it + 2, 10);
	v.erase(it+2);
	it = v.begin();
	while(it != v.end()){
		cout << *it << endl;
		it++;
	}
*/

}

